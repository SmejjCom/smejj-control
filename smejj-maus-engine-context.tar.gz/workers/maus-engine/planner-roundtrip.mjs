// smejj.com Maus-Engine — budgetierter Planner-Roundtrip (modellneutral).
// Single Responsibility: Aufgabe -> Plan -> Ausfuehrung; bei Fehlschlag
// maximal budget.maxPlannerRoundtrips Rueckfragen an den Planer. Der
// plannerClient wird vom AI Router injiziert (prompt -> Antworttext);
// dieses Modul kennt kein Modell. Lokale Retries passieren VORHER in der
// Engine — hier zaehlt nur der teure Modell-Aufruf (Kostenregel: kein
// Modell-Aufruf pro Klick, nur ein Plan pro Aufgabe plus Budget).
import { buildPlannerPrompt, buildRetryPrompt, PROMPT_TEMPLATE_VERSION } from "./prompt-template.mjs";
import { normalizePlannerOutput } from "./plan-normalizer.mjs";
import { validatePlan } from "./plan-validator.mjs";

// task: Aufgabentext; policyInput: { capsuleRef, domainAllowlist, budget,
// files?, visionAllowed? }; plannerClient: async (prompt) => Antworttext;
// runPlan: async (plan) => Engine-Ergebnis (executeRun/Interpreter).
export async function planAndExecute({ task, policyInput, plannerClient, runPlan }) {
  if (typeof plannerClient !== "function" || typeof runPlan !== "function") {
    throw new Error("planner_roundtrip_parameter_fehlen");
  }
  const maxRoundtrips = policyInput?.budget?.maxPlannerRoundtrips ?? 0;
  const history = [];
  let prompt = buildPlannerPrompt({ task, ...policyInput });
  let previousPlan = null;
  let lastFailure = null;

  // Aufruf 0 = Erstplan; danach bis zu maxRoundtrips Korrekturen.
  for (let call = 0; call <= maxRoundtrips; call += 1) {
    const rawAnswer = await plannerClient(prompt);
    const normalized = normalizePlannerOutput(rawAnswer);
    if (!normalized.ok) {
      lastFailure = { errors: [normalized.error] };
      history.push({ call, phase: "normalize", ok: false, error: normalized.error });
    } else {
      const plan = normalized.plan;
      const validation = validatePlan(plan);
      if (!validation.ok) {
        lastFailure = { errors: validation.errors.slice(0, 10) };
        history.push({ call, phase: "validate", ok: false, errors: lastFailure.errors });
        previousPlan = plan;
      } else {
        history.push({ call, phase: "validate", ok: true, planId: plan.planId });
        const result = await runPlan(plan);
        if (result.ok) {
          return { ok: true, plan, result, plannerCalls: call + 1, history };
        }
        lastFailure = {
          failedStep: result.failedStep,
          aborted: result.aborted,
          abortReason: result.abortReason,
          actionLog: result.actionLog,
          domExcerpt: result.failureContext?.domExcerpt
        };
        history.push({ call, phase: "run", ok: false, failedStep: result.failedStep ?? null, aborted: result.aborted === true });
        previousPlan = plan;
      }
    }
    if (call === maxRoundtrips) break;
    prompt = buildRetryPrompt({
      previousPlan: previousPlan ?? { planId: "kein-plan", hinweis: "vorherige Antwort war kein gueltiger Plan" },
      failure: lastFailure,
      roundtrip: call + 1
    });
  }

  // Budget erschoepft: fail-closed, keine weiteren Modell-Aufrufe.
  return {
    ok: false,
    error: "planner_budget_erschoepft",
    promptTemplateVersion: PROMPT_TEMPLATE_VERSION,
    plannerCalls: maxRoundtrips + 1,
    lastFailure,
    history
  };
}
