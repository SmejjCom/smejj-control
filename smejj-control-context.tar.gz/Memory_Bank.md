# Memory_Bank.md — smejj.com

Public-safe Stub. Die interne Memory Bank ist nicht Teil des oeffentlichen Build-Kontexts; Projektwissen laedt der Control Server spaeter aus IDrive e2 (Object Brain).
