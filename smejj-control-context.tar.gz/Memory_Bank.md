# smejj.com Memory Bank (Runtime-Stub)

Die produktive Memory Bank ist interne Betriebsdokumentation und wird NICHT im
oeffentlichen Build-Repo veroeffentlicht. Der Control Server laedt Projektwissen
zur Laufzeit aus IDrive e2 (Object Brain, Prefixe memory/ und rag/), sobald die
Storage-Anbindung konfiguriert ist. Fehlt dieses Wissen, arbeitet der Server
fail-safe mit reduziertem Kontext weiter.
