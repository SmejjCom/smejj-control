// smejj.com — Live-Internet-Suche (free-only, ohne API-Key, fail-closed).
// Quellen: DuckDuckGo HTML, DuckDuckGo Lite, Bing HTML — alle kostenlos, keine Keys,
// keine Paid-Fallbacks. Sicherheit: nur https, keine privaten Ziele (SSRF-Schutz),
// harte Timeouts, begrenzte Antwortgroessen. Fehler ergeben leere Resultate, nie Abbruch.

const SEARCH_TIMEOUT_MS = 8000;
const PAGE_TIMEOUT_MS = 6000;
const MAX_BODY_BYTES = 600000;
const MAX_EXCERPT_CHARS = 2200;
const USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 smejj-live-search";

const PRIVATE_HOST_PATTERN = /^(localhost$|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|0\.|\[?::1)/i;

function decodeEntities(text) {
  return String(text || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, String.fromCharCode(34))
    .replace(/&#x27;/g, String.fromCharCode(39))
    .replace(/&#39;/g, String.fromCharCode(39))
    .replace(/&nbsp;/g, " ");
}

function stripTags(html) {
  return decodeEntities(
    String(html || "")
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
  ).replace(/\s+/g, " ").trim();
}

// Werbe-/Redirect-Links der Suchmaschinen (keine echten Treffer) aussortieren.
const AD_URL_PATTERN = /(duckduckgo\.com\/y\.js|\/aclick|bing\.com\/aclk|duckduckgo\.com\/l\/|ad_provider=|ad_domain=)/i;

export function isAdOrRedirectUrl(target) {
  return AD_URL_PATTERN.test(String(target || ""));
}

export function isSafePublicUrl(target) {
  let parsed;
  try { parsed = new URL(target); } catch { return false; }
  if (parsed.protocol !== "https:") return false;
  if (PRIVATE_HOST_PATTERN.test(parsed.hostname)) return false;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(parsed.hostname)) return false;
  if (isAdOrRedirectUrl(target)) return false;
  return true;
}

async function fetchText(target, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(target, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "de,en;q=0.8",
        Accept: "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5"
      }
    });
    if (!response.ok) return "";
    const type = String(response.headers.get("content-type") || "");
    if (!/text\/html|text\/plain|application\/xhtml/.test(type)) return "";
    const reader = response.body && response.body.getReader ? response.body.getReader() : null;
    if (!reader) return (await response.text()).slice(0, MAX_BODY_BYTES);
    const chunks = [];
    let received = 0;
    while (received < MAX_BODY_BYTES) {
      const part = await reader.read();
      if (part.done) break;
      chunks.push(part.value);
      received += part.value.length;
    }
    try { await reader.cancel(); } catch { /* Stream bereits beendet */ }
    let merged = new Uint8Array(received);
    let offset = 0;
    for (const chunk of chunks) { merged.set(chunk, offset); offset += chunk.length; }
    return new TextDecoder().decode(merged.slice(0, MAX_BODY_BYTES));
  } catch {
    return "";
  } finally {
    clearTimeout(timer);
  }
}

function resolveDuckDuckGoLink(href) {
  const raw = decodeEntities(String(href || ""));
  if (raw.includes("duckduckgo.com/l/")) {
    const match = raw.match(/[?&]uddg=([^&]+)/);
    if (!match) return "";
    try { return decodeURIComponent(match[1]); } catch { return ""; }
  }
  if (raw.startsWith("http")) return raw;
  return "";
}

function parseDuckDuckGoHtml(html) {
  const results = [];
  const linkPattern = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  const snippetPattern = /<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
  const snippets = [];
  let match;
  while ((match = snippetPattern.exec(html)) !== null) snippets.push(stripTags(match[1]));
  let index = 0;
  while ((match = linkPattern.exec(html)) !== null) {
    const url = resolveDuckDuckGoLink(match[1]);
    const title = stripTags(match[2]);
    if (url && title && isSafePublicUrl(url)) {
      results.push({ title, url, snippet: snippets[index] || "" });
    }
    index += 1;
  }
  return results;
}

function parseDuckDuckGoLite(html) {
  const results = [];
  const pattern = /<a[^>]+href="([^"]+)"[^>]*class=.result-link.[^>]*>([\s\S]*?)<\/a>/g;
  let match;
  while ((match = pattern.exec(html)) !== null) {
    const url = resolveDuckDuckGoLink(match[1]);
    const title = stripTags(match[2]);
    if (url && title && isSafePublicUrl(url)) results.push({ title, url, snippet: "" });
  }
  return results;
}

function parseBingHtml(html) {
  const results = [];
  const pattern = /<li class="b_algo"[\s\S]*?<h2[^>]*><a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let match;
  while ((match = pattern.exec(html)) !== null) {
    const url = decodeEntities(match[1]);
    const title = stripTags(match[2]);
    if (title && isSafePublicUrl(url)) results.push({ title, url, snippet: "" });
  }
  return results;
}

export async function searchWeb(query, options) {
  const settings = options || {};
  const limit = Math.min(Math.max(Number(settings.limit) || 5, 1), 10);
  const trimmed = String(query || "").trim().slice(0, 300);
  if (!trimmed) return [];
  const encoded = encodeURIComponent(trimmed);
  const attempts = [
    { url: "https://html.duckduckgo.com/html/?q=" + encoded + "&kl=de-de", parse: parseDuckDuckGoHtml },
    { url: "https://lite.duckduckgo.com/lite/?q=" + encoded, parse: parseDuckDuckGoLite },
    { url: "https://www.bing.com/search?q=" + encoded + "&setlang=de", parse: parseBingHtml }
  ];
  for (const attempt of attempts) {
    const html = await fetchText(attempt.url, SEARCH_TIMEOUT_MS);
    if (!html) continue;
    const results = attempt.parse(html);
    if (results.length > 0) return results.slice(0, limit);
  }
  return [];
}

export async function fetchPageExcerpt(target) {
  if (!isSafePublicUrl(target)) return "";
  const html = await fetchText(target, PAGE_TIMEOUT_MS);
  if (!html) return "";
  const body = html.replace(/^[\s\S]*?<body[^>]*>/i, " ").replace(/<\/body>[\s\S]*$/i, " ");
  return stripTags(body).slice(0, MAX_EXCERPT_CHARS);
}

const WEB_INTENT_PATTERN = /(internet|web|online|news|nachrichten|aktuell|heute|jetzt|gerade|latest|current|neueste|preis|price|kurs|wetter|weather|today|202\d|wer ist|was ist|wie viel|wieviel|wann |wo |suche |search )/i;

export function shouldSearchWeb(task) {
  const text = String(task || "").trim();
  if (!text || text.length > 400) return false;
  if (text.includes(String.fromCharCode(96, 96, 96))) return false;
  if (/unified diff|\bpatch\b|\brefactor/i.test(text)) return false;
  if (WEB_INTENT_PATTERN.test(text)) return true;
  return /\?\s*$/.test(text);
}

export async function buildWebContextBlock(query, options) {
  try {
    const settings = options || {};
    const results = await searchWeb(query, { limit: settings.maxResults || 5 });
    if (results.length === 0) return "";
    const lines = results.map(function (result, index) {
      const head = (index + 1) + ". " + result.title;
      const src = "   " + result.url;
      return result.snippet ? head + "\n" + src + "\n   " + result.snippet : head + "\n" + src;
    });
    const excerpts = [];
    const pageCount = Math.min(settings.withPages === undefined ? 2 : settings.withPages, results.length);
    for (let index = 0; index < pageCount; index += 1) {
      const excerpt = await fetchPageExcerpt(results[index].url);
      if (excerpt) excerpts.push("Auszug aus " + results[index].url + ":\n" + excerpt);
    }
    const header = "Live-Internet-Kontext (Websuche vom " + new Date().toISOString() + "):";
    return [header, lines.join("\n")].concat(excerpts).join("\n\n");
  } catch {
    return "";
  }
}
