// smejj.com — Passkey-UI-Verdrahtung (Single Responsibility: Buttons im Konto-View).
// Bewusst als eigenes Modul, damit app.js unveraendert bleibt (Ratchet-Baseline).
// Bindet "Passkey einrichten" und "Mit Passkey anmelden" an public/auth/passkey.js.
import { hasPlatformAuthenticator, isPasskeySupported, loginWithPasskey, registerPasskey } from "./passkey.js";

const SESSION_KEY = "smejj.session.v1";

function ready(fn) {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn, { once: true });
  else fn();
}

function writeOutput(message) {
  const out = document.getElementById("profileOutput");
  if (out) out.textContent = message;
}

function setSessionStatus(text) {
  const el = document.getElementById("sessionStatus");
  if (el) el.textContent = text;
}

function persistSession(user) {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify({
      authenticated: true,
      mode: "passkey",
      user: { name: user?.name || "Passkey Nutzer", email: user?.email || "", userId: user?.userId || "" }
    }));
  } catch {
    // Speichern ist optional.
  }
}

ready(async () => {
  const registerBtn = document.getElementById("passkeyRegister");
  const loginBtn = document.getElementById("passkeyLogin");
  if (!registerBtn && !loginBtn) return;

  if (!isPasskeySupported()) {
    for (const btn of [registerBtn, loginBtn]) {
      if (!btn) continue;
      btn.disabled = true;
      btn.title = "Dieses Geraet/dieser Browser unterstuetzt keine Passkeys.";
    }
    return;
  }
  // Reiner Hinweis, ob Face ID/Touch ID (Plattform-Authenticator) verfuegbar ist.
  const platform = await hasPlatformAuthenticator();
  if (platform && registerBtn) registerBtn.title = "Face ID / Touch ID / Fingerabdruck einrichten";

  registerBtn?.addEventListener("click", async () => {
    const email = document.getElementById("profileEmail")?.value?.trim() || "";
    const displayName = document.getElementById("profileName")?.value?.trim() || email || "smejj.com Nutzer";
    registerBtn.disabled = true;
    writeOutput("Passkey wird eingerichtet — bitte per Face ID / Touch ID / Fingerabdruck bestaetigen ...");
    try {
      const result = await registerPasskey({ email, displayName });
      persistSession(result.user);
      setSessionStatus(`angemeldet (Passkey) — ${result.user?.email || result.user?.name || ""}`.trim());
      writeOutput("Passkey eingerichtet und angemeldet. Kein Passwort wurde gespeichert oder gesendet.");
    } catch (error) {
      writeOutput(`Passkey einrichten fehlgeschlagen: ${error?.message || error}`);
    } finally {
      registerBtn.disabled = false;
    }
  });

  loginBtn?.addEventListener("click", async () => {
    const email = document.getElementById("profileEmail")?.value?.trim() || "";
    loginBtn.disabled = true;
    writeOutput("Anmeldung mit Passkey — bitte per Face ID / Touch ID / Fingerabdruck bestaetigen ...");
    try {
      const result = await loginWithPasskey({ email });
      persistSession(result.user);
      setSessionStatus(`angemeldet (Passkey) — ${result.user?.email || result.user?.name || ""}`.trim());
      writeOutput("Mit Passkey angemeldet. Kein Passwort wurde gespeichert oder gesendet.");
    } catch (error) {
      writeOutput(`Passkey-Anmeldung fehlgeschlagen: ${error?.message || error}`);
    } finally {
      loginBtn.disabled = false;
    }
  });
});
